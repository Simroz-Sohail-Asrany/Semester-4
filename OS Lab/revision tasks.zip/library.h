#ifndef LIBRARY_H
#define LIBRARY_H

#define MAX_BOOKS 100

struct Book {
    int id;
    char name[100];
    int isIssued;  
};

void addBook();
void issueBook();

#endif

