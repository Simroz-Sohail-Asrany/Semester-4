#include <stdio.h>
#include <string.h>
#include "library.h"

extern struct Book books[MAX_BOOKS];
extern int bookCount;

void addBook() {
    if (bookCount >= MAX_BOOKS) {
        printf("Library is full!\n");
        return;
    }

    printf("Enter Book ID: ");
    scanf("%d", &books[bookCount].id);

    printf("Enter Book Name: ");
    scanf(" %[^\n]", books[bookCount].name);

    books[bookCount].isIssued = 0;

    bookCount++;
    printf("Book added successfully!\n");
}

