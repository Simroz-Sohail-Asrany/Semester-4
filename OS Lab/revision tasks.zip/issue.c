#include <stdio.h>
#include "library.h"

extern struct Book books[MAX_BOOKS];
extern int bookCount;

void issueBook() {
    int id;
    int found = 0;

    printf("Enter Book ID to issue: ");
    scanf("%d", &id);

    for (int i = 0; i < bookCount; i++) {
        if (books[i].id == id) {
            found = 1;
            if (books[i].isIssued == 0) {
                books[i].isIssued = 1;
                printf("Book issued successfully!\n");
            } else {
                printf("Book is already issued!\n");
            }
            break;
        }
    }

    if (!found) {
        printf("Book not found!\n");
    }
}


